package br.clientec;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

public class SelPratos {

	private String nome;
	private float  preco;
	private int codigo;
	private ArrayList listaContatos = new ArrayList();

	

//	public Usuario selecionarPrato(int codigo) {
//
//		Usuario c = new Usuario();
//
//		try {
//			Class.forName("org.postgresql.Driver");
//			Connection con = null;
//			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/CRUD", "postgres", // usu�rio
//																									// bd
//					"postgres" // senha bd
//			);
//			if (con != null) { // in�cio do IF
//				String sql = "select * from USUARIOS where CODIGO = ?";
//
//				PreparedStatement query = con.prepareStatement(sql);
//				query.setInt(1, codigo);
//
//				ResultSet resultado = query.executeQuery();
//
//				if (resultado.next()) {
//					c.setNome(resultado.getString("NOME"));
//					c.setEndereco(resultado.getString("ENDERECO"));
//					c.setEmail(resultado.getString("EMAIL"));
//					c.setCodigo(resultado.getInt("CODIGO"));
//					c.setLogin(resultado.getString("LOGIN"));
//					c.setSenha(resultado.getString("SENHA"));
//				}
//
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return c;
//	}

	public ArrayList selecionarTodosPratos() {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = null;
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/CRUD", "postgres","postgres");
		
			if (con != null) { // in�cio do IF
				String sql = "select * from pratos order by codigo";
				Statement query = con.createStatement();
				ResultSet resultado = query.executeQuery(sql);
				
				while (resultado.next()) {
					SelPratos c = new SelPratos();
					c.setNome(resultado.getString("NOME"));
					c.setCodigo(resultado.getInt("CODIGO"));
					c.setPreco(resultado.getFloat("PRECO"));
//					c.setEndereco(resultado.getString("ENDERECO"));
//					c.setEmail(resultado.getString("EMAIL"));			
//					c.setLogin(resultado.getString("LOGIN"));
//					c.setSenha(resultado.getString("SENHA"));
					listaContatos.add(c);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return listaContatos;

	}
		
//		public boolean deletarUsuario(Usuario c) {		
//			try {
//				Class.forName("org.postgresql.Driver");
//				Connection con = null;
//				con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/CRUD", "postgres", "postgres");
//				if (con != null) {
//					String sql = "DELETE FROM USUARIOS  WHERE CODIGO = ? ";
//					PreparedStatement deleta = con.prepareStatement(sql);
//					deleta.setInt(1, c.getCodigo());
//					deleta.execute();
//					deleta.close();
//					return true;				
//				}
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//
//			return false;
//		}
//
//	public boolean inserirContato(Usuario c) {
//		// vamos programar a l�gica do BD aqui
//		try {
//			Class.forName("org.postgresql.Driver");
//			Connection con = null;
//			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/CRUD", "postgres", // usu�rio
//																									// bd
//					"postgres" // senha bd
//			);
//			if (con != null) { // in�cio do IF
//				String sql = "insert into USUARIOS (NOME, EMAIL, ENDERECO, LOGIN, SENHA) values (?, ?, ? , ? ,?)";
//				PreparedStatement inserir = con.prepareStatement(sql);
//				inserir.setString(1, c.getNome());
//				inserir.setString(2, c.getEmail());
//				inserir.setString(3, c.getEndereco());
//				inserir.setString(4, c.getLogin());
//				inserir.setString(5, c.getSenha());
//				inserir.executeUpdate();
//				inserir.close();
//				con.close();
//				return true;
//			} // fim do IF
//		} // fim do try
//		catch (Exception e) { // in�cio do catch
//			e.printStackTrace();
//		} // fim do catch
//		return false;
//	}

	public String getNome() {
		return nome;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public float getPreco() {
		return preco;
	}

	public void setPreco(float preco) {
		this.preco = preco;
	}
	
	
}