package br.clientec;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

public class Usuario {

	private String nome;
	private String endereco;
	private String email;
	private String senha;
	private String login;
	private ResultSet checado;

	private ArrayList listaContatos = new ArrayList();

	private int codigo;

	public Usuario selecionarContato(int codigo) {

		Usuario c = new Usuario();

		try {
			Class.forName("org.postgresql.Driver");
			Connection con = null;
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/CRUD", "postgres", // usu�rio
																									// bd
					"postgres" // senha bd
			);
			if (con != null) { // in�cio do IF
				String sql = "select * from USUARIOS where CODIGO = ?";

				PreparedStatement query = con.prepareStatement(sql);
				query.setInt(1, codigo);

				ResultSet resultado = query.executeQuery();

				if (resultado.next()) {
					c.setNome(resultado.getString("NOME"));
					c.setEndereco(resultado.getString("ENDERECO"));
					c.setEmail(resultado.getString("EMAIL"));
					c.setCodigo(resultado.getInt("CODIGO"));
					c.setLogin(resultado.getString("LOGIN"));
					c.setSenha(resultado.getString("SENHA"));
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return c;
	}

	public ArrayList selecionarTodosContatos() {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = null;
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/CRUD", "postgres", // usu�rio
																									// bd
					"postgres"// senha bd
			);
			if (con != null) { // in�cio do IF
				String sql = "select * from USUARIOS order by codigo";
				Statement query = con.createStatement();
				ResultSet resultado = query.executeQuery(sql);

				while (resultado.next()) {
					Usuario c = new Usuario();
					c.setNome(resultado.getString("NOME"));
					c.setEndereco(resultado.getString("ENDERECO"));
					c.setEmail(resultado.getString("EMAIL"));
					c.setCodigo(resultado.getInt("CODIGO"));
					c.setLogin(resultado.getString("LOGIN"));
					c.setSenha(resultado.getString("SENHA"));
					listaContatos.add(c);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return listaContatos;

	}
		
		public boolean deletarUsuario(Usuario c) {		
			try {
				Class.forName("org.postgresql.Driver");
				Connection con = null;
				con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/CRUD", "postgres", "postgres");
				if (con != null) {
					String sql = "DELETE FROM USUARIOS  WHERE CODIGO = ? ";
					PreparedStatement deleta = con.prepareStatement(sql);
					deleta.setInt(1, c.getCodigo());
					deleta.execute();
					deleta.close();
					return true;				
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return false;
		}

	public boolean inserirContato(Usuario c) {
		// vamos programar a l�gica do BD aqui
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = null;
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/CRUD", "postgres", // usu�rio
																									// bd
					"postgres" // senha bd
			);
			if (con != null) { // in�cio do IF
				String sql = "insert into USUARIOS (NOME, EMAIL, ENDERECO, LOGIN, SENHA) values (?, ?, ? , ? ,?)";
				PreparedStatement inserir = con.prepareStatement(sql);
				inserir.setString(1, c.getNome());
				inserir.setString(2, c.getEmail());
				inserir.setString(3, c.getEndereco());
				inserir.setString(4, c.getLogin());
				inserir.setString(5, c.getSenha());
				inserir.executeUpdate();
				inserir.close();
				con.close();
				return true;
			} // fim do IF
		} // fim do try
		catch (Exception e) { // in�cio do catch
			e.printStackTrace();
		} // fim do catch
		return false;
	}

	public String getNome() {
		return nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public String getEmail() {
		return email;
	}

	public int getCodigo() {
		return codigo;
	}

	public String getSenha() {
		return senha;
	}

	public String getLogin() {
		return login;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public void setLogin(String login) {
		this.login = login;
	}

}