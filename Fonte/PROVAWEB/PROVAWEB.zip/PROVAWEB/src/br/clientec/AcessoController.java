package br.clientec;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

@RequestScoped
@ManagedBean
public class AcessoController {
	Acesso c1 = new Acesso();
	private boolean passou;
	private String username;
	private String password;

	@PostConstruct
	public void init() {
		System.out.println("O bean foi executado!!!");

	}

	public void autenticarControl() {
		//System.out.println("M�TODO AUTENTICAR");
		Acesso ac = new Acesso();
		passou = ac.Autenticar(c1);
		// ac.Autenticar(c1.setUsuario(usuario)
		if (passou == true) {
			System.out.println("LOGADO COM SUCESSO");
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect("SelPratos.jsf");
		} catch (IOException e) {
			e.printStackTrace();
		}  
		} else {
			System.out.println("ERRO DE AUTENTICACAO.");
			
//			FacesContext.getCurrentInstance().addMessage("atenticarControl",
//					new FacesMessage(FacesMessage.SEVERITY_INFO,
//					"Senha ou usu�rio inv�lidos!", ""));
		}
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Acesso getC1() {
		return c1;
	}

	public void setC1(Acesso c1) {
		this.c1 = c1;
	}

}
