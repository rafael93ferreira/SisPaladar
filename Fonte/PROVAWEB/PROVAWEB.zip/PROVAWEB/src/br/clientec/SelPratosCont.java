package br.clientec;

import java.util.ArrayList;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import org.primefaces.event.SelectEvent;

@RequestScoped
@ManagedBean
public class SelPratosCont {
//	SelPratos c1 = new SelPratos();
	ArrayList listaPratos = new ArrayList();
	
	@PostConstruct
	public void init() {
		System.out.println("O bean foi executado!!!");
		SelPratos c = new SelPratos();
		listaPratos = c.selecionarTodosPratos();
	}
   
//	public void inserirContato() {
//		Usuario c = new Usuario();
//		if (c.inserirContato(c1) == true) {
//			System.out.println("Cliente Inserido com sucesso.");
//			listaPratos = c.selecionarTodosContatos();
//		} else {
//			System.out.println("Cliente obteve falha na inser��o!!");
//		}
//	}
				
				
//	public void deletaCliente(){
//		Usuario ac = new Usuario();
//		if (ac.deletarUsuario(c1) == true) {
//			System.out.println(c1);
//			System.out.println("Cliente deletado!");
//			listaPratos = ac.selecionarTodosContatos();
//		}else{
//			System.out.println("Erro ao deletar com o Cliente");
//		}
//	}

//	public ArrayList getListaContatos() {
//		return listaContatos;
//	}
//	public void setListaContatos(ArrayList listaContatos) {
//		this.listaContatos = listaContatos;
//	}
//	public Usuario getC1() {
//		return c1;
//	}
//	public void setC1(Usuario c1) {
//		this.c1 = c1;
//	}

	
	public ArrayList getListaPratos() {
		return listaPratos;
	}

	
	public void setListaPratos(ArrayList listaPratos) {
		this.listaPratos = listaPratos;
	}

}