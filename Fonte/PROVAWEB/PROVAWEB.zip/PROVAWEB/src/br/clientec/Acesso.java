package br.clientec;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Acesso {

	private String usuario;
	private String senha;
	private ResultSet checado;

	public boolean Autenticar(Acesso c) {		
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = null;

			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/CRUD", "postgres", "postgres");

			if (con != null) {
				String sql = "select * from usuarios where LOGIN = ? and SENHA = ? ";
           //autentica��o por Bruno Meirelles 05-05-2016
				PreparedStatement inserir = con.prepareStatement(sql);
				inserir.setString(1, c.getUsuario());
				inserir.setString(2, c.getSenha());
				checado = inserir.executeQuery();
				if (checado.next()) {
					return true;
				} else {
					return false;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}


}
